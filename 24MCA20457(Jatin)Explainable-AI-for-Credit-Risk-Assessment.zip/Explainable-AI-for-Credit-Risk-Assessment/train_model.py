"""
Credit Risk Prediction Model with Explainable AI
=================================================

This script trains an XGBoost model to predict credit risk using the LendingClub dataset.
It focuses on being beginner-friendly with clear explanations at each step.

Author: Your Name
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report, 
    confusion_matrix, 
    roc_auc_score,
    precision_recall_curve,
    f1_score
)
import xgboost as xgb
import shap
import pickle
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("CREDIT RISK PREDICTION MODEL")
print("=" * 60)

# Step 1: Load and prepare data
print("\n[Step 1] Loading data...")
# Using more data for better model performance (20,000 rows)
df = pd.read_csv('credit-risk-xai/data/accepted_2007_to_2018Q4.csv.gz', nrows=20000)
print(f"✓ Loaded {len(df):,} rows with {len(df.columns)} columns")

# Step 2: Create target variable
print("\n[Step 2] Creating target variable...")
# 'Charged Off' means the borrower couldn't pay back (bad loan)
df['target'] = (df['loan_status'] == 'Charged Off').astype(int)
print(f"✓ Bad loans (target=1): {df['target'].sum():,} ({df['target'].mean():.1%})")
print(f"✓ Good loans (target=0): {(~df['target'].astype(bool)).sum():,}")

# Step 3: Feature Engineering
print("\n[Step 3] Creating features...")

# Clean numeric columns
if df['int_rate'].dtype == 'object':
    df['int_rate'] = df['int_rate'].str.rstrip('%').astype(float)

# Fill missing values in numeric columns
df['annual_inc'] = df['annual_inc'].fillna(df['annual_inc'].median())
df['loan_amnt'] = df['loan_amnt'].fillna(df['loan_amnt'].median())
df['installment'] = df['installment'].fillna(df['installment'].median())
df['int_rate'] = df['int_rate'].fillna(df['int_rate'].median())

# Create new features (these are engineered features that help predict risk)
df['loan_to_income'] = df['loan_amnt'] / df['annual_inc'].clip(lower=1)  # Higher = riskier
df['log_annual_inc'] = np.log1p(df['annual_inc'])  # Log transform for better model performance
df['installment_to_income'] = df['installment'] / df['annual_inc'].clip(lower=1)  # Monthly burden

# Add term as numeric (36 or 60 months)
df['term_numeric'] = df['term'].str.replace(' months', '').astype(float)

# Encode categorical variables
df['home_ownership_numeric'] = df['home_ownership'].map({
    'OWN': 3,
    'MORTGAGE': 2, 
    'RENT': 1,
    'OTHER': 0
}).fillna(1)

# Select final features to use
features = [
    'loan_amnt',           # Original loan amount
    'int_rate',            # Interest rate
    'annual_inc',          # Annual income
    'installment',         # Monthly payment
    'loan_to_income',      # How much loan vs income (engineered)
    'log_annual_inc',      # Log of income (engineered)
    'installment_to_income', # Monthly payment vs income (engineered)
    'term_numeric',        # Loan term (engineered)
    'home_ownership_numeric' # Home ownership (engineered)
]

print(f"✓ Created {len(features)} features for the model")

# Step 4: Prepare data for training
print("\n[Step 4] Preparing data for training...")
# Drop rows with missing values
df_clean = df[features + ['target']].dropna()
print(f"✓ Clean dataset: {len(df_clean):,} rows")

# Split into features and target
X = df_clean[features]
y = df_clean['target']

# Split into training and testing sets (60% train, 40% test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.4, random_state=42, stratify=y
)
print(f"✓ Training set: {len(X_train):,} rows")
print(f"✓ Testing set: {len(X_test):,} rows")

# Step 5: Train the model
print("\n[Step 5] Training XGBoost model...")

# Calculate class weight to handle imbalanced data
pos_rate = y_train.mean()
neg_pos_ratio = (1 - pos_rate) / max(pos_rate, 1e-9)

# XGBoost parameters (carefully tuned for better performance)
model = xgb.XGBClassifier(
    n_estimators=200,      # Number of trees (increased for better performance)
    max_depth=5,           # Tree depth
    learning_rate=0.05,    # Lower learning rate for more stable learning
    subsample=0.85,        # Use 85% of data for each tree
    colsample_bytree=0.85, # Use 85% of features for each tree
    min_child_weight=2,    # Minimum samples per leaf
    random_state=42,       # For reproducibility
    scale_pos_weight=neg_pos_ratio,  # Handle imbalanced classes
    eval_metric='logloss',
    n_jobs=-1              # Use all CPU cores for faster training
)

# Train the model
model.fit(X_train, y_train)
print("✓ Model training completed!")

# Step 6: Evaluate the model
print("\n[Step 6] Evaluating model...")

# Get predictions
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)
y_test_proba = model.predict_proba(X_test)[:, 1]

# Calculate metrics
train_acc = (y_train_pred == y_train).mean()
test_acc = (y_test_pred == y_test).mean()
auc_score = roc_auc_score(y_test, y_test_proba)
f1 = f1_score(y_test, y_test_pred)

print(f"\n📊 Model Performance:")
print(f"  Training Accuracy: {train_acc:.2%}")
print(f"  Test Accuracy:     {test_acc:.2%}")
print(f"  AUC Score:         {auc_score:.4f}")
print(f"  F1 Score:          {f1:.4f}")

# Confusion Matrix
cm = confusion_matrix(y_test, y_test_pred)
print(f"\n📋 Confusion Matrix:")
print(f"                Predicted")
print(f"              Good    Bad")
print(f"  Actual Good {cm[0][0]:4d}   {cm[0][1]:4d}")
print(f"        Bad   {cm[1][0]:4d}   {cm[1][1]:4d}")

# Classification Report
print(f"\n📝 Detailed Report:")
print(classification_report(y_test, y_test_pred, target_names=['Good Loan', 'Bad Loan']))

# Step 7: Find optimal threshold
print("\n[Step 7] Finding optimal decision threshold...")
# Calculate precision, recall at different thresholds
precision, recall, thresholds = precision_recall_curve(y_test, y_test_proba)
# Calculate F1 score for each threshold
f1_scores = 2 * (precision * recall) / (precision + recall + 1e-10)
# Find threshold that gives best F1 score
best_idx = np.argmax(f1_scores)
best_threshold = thresholds[max(best_idx - 1, 0)]
print(f"✓ Optimal threshold: {best_threshold:.3f}")
print(f"  (Default is 0.5, but {best_threshold:.3f} gives better results)")

# Step 8: Save the model and explainer
print("\n[Step 8] Saving model and SHAP explainer...")

# Save model
with open('best_model.pkl', 'wb') as f:
    pickle.dump(model, f)
print("✓ Saved best_model.pkl")

# Save feature names
with open('feature_names.pkl', 'wb') as f:
    pickle.dump(features, f)
print("✓ Saved feature_names.pkl")

# Save optimal threshold
with open('best_threshold.pkl', 'wb') as f:
    pickle.dump(float(best_threshold), f)
print("✓ Saved best_threshold.pkl")

# Step 9: Create SHAP explainer for explainability
print("\n[Step 9] Creating SHAP explainer (this may take a moment)...")
explainer = shap.TreeExplainer(model)
print("✓ SHAP explainer created")

# Calculate feature importance
shap_values = explainer.shap_values(X_test[:100])  # Use subset for speed
if isinstance(shap_values, list):
    shap_values = shap_values[1]  # Get values for class 1 (bad loans)

# Feature importance
feature_importance = pd.DataFrame({
    'Feature': features,
    'Importance': np.abs(shap_values).mean(0)
}).sort_values('Importance', ascending=False)

print(f"\n🔍 Feature Importance (Top 5):")
print(feature_importance.head())

# Save SHAP explainer
with open('explainer.pkl', 'wb') as f:
    pickle.dump(explainer, f)
print("✓ Saved explainer.pkl")

print("\n" + "=" * 60)
print("🎉 MODEL TRAINING COMPLETE!")
print("=" * 60)
print("\nNext steps:")
print("1. Run: streamlit run app.py")
print("2. Input loan details in the web interface")
print("3. See the prediction and explanation!")

